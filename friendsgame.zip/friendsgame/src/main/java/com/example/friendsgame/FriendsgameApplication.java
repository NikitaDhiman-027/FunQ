package com.example.friendsgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendsgameApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendsgameApplication.class, args);
	}

}
