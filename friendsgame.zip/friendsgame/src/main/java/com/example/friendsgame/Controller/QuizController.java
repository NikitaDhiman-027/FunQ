package com.example.friendsgame.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.friendsgame.Entity.QuizResponse;
import com.example.friendsgame.Repository.QuizRepository;
import com.example.friendsgame.Service.ScoringService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class QuizController {

    private final QuizRepository quizRepository;
    private final ScoringService scoringService;

    @GetMapping("/")
    public String welcomePage() {
        return "welcome"; // welcome.html
    }

    @GetMapping("/form")
    public String quizPage(Model model) {
        model.addAttribute("response", new QuizResponse());
        return "form"; // form.html
    }

    @PostMapping("/submit")
    public String submit(@ModelAttribute QuizResponse r, Model model) {

        r.setHasBfGfScore(scoringService.scoreBfGf(r.getHasBfGfChoice()));
        r.setExCountScore(scoringService.scoreExCount(r.getExCountChoice()));
        r.setLoveOpinionScore(scoringService.scoreLoveOpinion(r.getLoveOpinionChoice()));
        r.setNightThoughtScore(scoringService.scoreNightThought(r.getNightThoughtChoice()));
        r.setLoveLanguageScore(scoringService.scoreLoveLanguage(r.getLoveLanguageChoice()));
        r.setCrushReactionScore(scoringService.scoreCrushReaction(r.getCrushReactionChoice()));
        r.setRelationStatusScore(scoringService.scoreRelationStatus(r.getRelationStatusChoice()));

        int total = r.getHasBfGfScore()
                + r.getExCountScore()
                + r.getLoveOpinionScore()
                + r.getNightThoughtScore()
                + r.getLoveLanguageScore()
                + r.getCrushReactionScore()
                + r.getRelationStatusScore();

        r.setTotalScore(total);
        r.setResultTitle(scoringService.titleForTotal(total));

        quizRepository.save(r);

        model.addAttribute("result", r);
        return "result"; // result.html
    }
}
