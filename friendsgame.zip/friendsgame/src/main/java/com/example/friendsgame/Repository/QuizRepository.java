package com.example.friendsgame.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.friendsgame.Entity.QuizResponse;

@Repository
public interface QuizRepository
        extends JpaRepository<QuizResponse, Long> {
}
