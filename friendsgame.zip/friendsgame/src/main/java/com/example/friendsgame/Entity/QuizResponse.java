package com.example.friendsgame.Entity; // 🔁 lowercase "entity" is conventional

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "friends_game")
@Data
public class QuizResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "uname")
    private String name;

    @Column(name = "bmonth")
    private String birthdayMonth;

    @Column(name = "bff")
    private String bestFriendName;

    @Column(name = "partner")
    private String partnerName;

    /* raw radio choices */
    @Column(name = "bf_gf")
    private String hasBfGfChoice;

    @Column(name = "ex")
    private String exCountChoice;

    @Column(name = "lop") // love opinion
    private String loveOpinionChoice;

    @Column(name = "nth") // night thought
    private String nightThoughtChoice;

    @Column(name = "ll") // love language
    private String loveLanguageChoice;

    @Column(name = "crush")
    private String crushReactionChoice;

    @Column(name = "rel")
    private String relationStatusChoice;

    /* scores */
    @Column(name = "bf_gf_s")
    private int hasBfGfScore;

    @Column(name = "ex_s")
    private int exCountScore;

    @Column(name = "lop_s")
    private int loveOpinionScore;

    @Column(name = "nth_s")
    private int nightThoughtScore;

    @Column(name = "ll_s")
    private int loveLanguageScore;

    @Column(name = "crush_s")
    private int crushReactionScore;

    @Column(name = "rel_s")
    private int relationStatusScore;

    @Column(name = "tscore")
    private int totalScore;

    @Column(name = "result")
    private String resultTitle;

    @CreationTimestamp
    @Column(name = "submitted")
    private LocalDateTime submittedAt;
}
