package com.example.friendsgame.Service;

import org.springframework.stereotype.Service;

@Service
public class ScoringService {

    public int scoreBfGf(String c) {
        if ("YES".equals(c))
            return 5;
        if ("NO".equals(c))
            return 2;
        if ("COMPLICATED".equals(c))
            return 3;
        if ("LEGEND".equals(c))
            return 1;
        return 0;
    }

    public int scoreExCount(String c) {
        if ("ZERO".equals(c))
            return 1;
        if ("ONE".equals(c))
            return 3;
        if ("TWO_THREE".equals(c))
            return 4;
        if ("LOST_COUNT".equals(c))
            return 5;
        return 0;
    }

    public int scoreLoveOpinion(String c) {
        if ("BEST".equals(c))
            return 5;
        if ("RISKY".equals(c))
            return 3;
        if ("OVERRATED".equals(c))
            return 2;
        if ("SINGLE_FOREVER".equals(c))
            return 1;
        return 0;
    }

    public int scoreNightThought(String c) {
        if ("GOALS".equals(c))
            return 4;
        if ("MESSAGES".equals(c))
            return 3;
        if ("EX_SCREENSHOTS".equals(c))
            return 2;
        if ("FOOD".equals(c))
            return 5;
        return 0;
    }

    public int scoreLoveLanguage(String c) {
        if ("GIFTS".equals(c))
            return 4;
        if ("MEMES".equals(c))
            return 5;
        if ("TEXTS".equals(c))
            return 3;
        if ("IGNORE_THEN_MISS".equals(c))
            return 2;
        return 0;
    }

    public int scoreCrushReaction(String c) {
        if ("CRY_ALONE".equals(c))
            return 3;
        if ("BLOCK_ALL".equals(c))
            return 2;
        if ("IGNORE".equals(c))
            return 1;
        if ("I_AM_THE_EX".equals(c))
            return 5;
        return 0;
    }

    public int scoreRelationStatus(String c) {
        if ("LOYAL".equals(c))
            return 4;
        if ("SINGLE".equals(c))
            return 2;
        if ("CONFUSED".equals(c))
            return 3;
        if ("FLIRTY".equals(c))
            return 5;
        return 0;
    }

    public String titleForTotal(int total) {
        if (total >= 36)
            return "💘 Lover No. 1";
        if (total >= 26)
            return "😂 Meme Lover with Feelings";
        if (total >= 16)
            return "😅 Confused Romeo";
        return "😭 Forever Single";
    }
}
